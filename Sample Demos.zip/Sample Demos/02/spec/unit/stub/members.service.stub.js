"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var MembersServiceSpy = (function () {
    function MembersServiceSpy() {
        var _this = this;
        this.members = {
            "id": 2,
            "name": "MS Dhoni",
            "phone": "+91 7202139876",
            "address": {
                "street": "Harmu Housing Colony,",
                "city": "Ranchi, , ",
                "state": "Jharkhand",
                "zip": "4880202"
            }
        };
        this.getData = jasmine.createSpy('getData').and.callFake(function () { return Promise
            .resolve(true)
            .then(function () { return Object.assign({}, _this.members); }); });
        this.getPerson = jasmine.createSpy('getPerson').and.callFake(function () { return Promise
            .resolve(true)
            .then(function () { return Object.assign({}, _this.members); }); });
        this.searchQuery = jasmine.createSpy('searchQuery').and.callFake(function () { return Promise
            .resolve(true)
            .then(function () { return Object.assign({}, _this.members); }); });
    }
    return MembersServiceSpy;
}());
exports.MembersServiceSpy = MembersServiceSpy;
//# sourceMappingURL=members.service.stub.js.map